The files for each question are unique and all subparts are included in one file.
For Q3, we have to pass the file to be read as an argument while executing the shell script, as in `./Q3.sh filename.txt'.

Repository link: https://github.com/DruhanShah/ISS-Assignment-1.git
